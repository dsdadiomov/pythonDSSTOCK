from Stock_package.Stocks import Stock
from Stock_package import Stock